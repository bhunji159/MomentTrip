package com.example.momenttrip.ui.screen.main

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun CurrentTripScreen(modifier: Modifier = Modifier) {
    
}