package com.example.momenttrip.ui.screen.main

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTripScreen(
    onLogout: () -> Unit
) {
    val context = LocalContext.current

    val tripName = remember { mutableStateOf("") }
    val selectedCountry = remember { mutableStateOf<String?>(null) }
    val selectedDates = remember { mutableStateOf<Pair<LocalDate?, LocalDate?>>(null to null) }

    val showCountrySheet = remember { mutableStateOf(false) }
    val showDateSheet = remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = {
                    FirebaseAuth.getInstance().signOut()
                    Toast.makeText(context, "로그아웃 되었습니다.", Toast.LENGTH_SHORT).show()
                    onLogout()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("로그아웃", color = MaterialTheme.colorScheme.onPrimary)
            }
            OutlinedTextField(
                value = tripName.value,
                onValueChange = { tripName.value = it },
                label = { Text("여행 이름") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { showCountrySheet.value = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = selectedCountry.value ?: "나라 선택")
            }

            Button(
                onClick = { showDateSheet.value = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                val (start, end) = selectedDates.value
                Text(text = if (start != null && end != null)
                    "${start} ~ ${end}" else "기간 선택")
            }

            Button(
                onClick = {
                    if (tripName.value.isBlank() || selectedCountry.value == null || selectedDates.value.first == null || selectedDates.value.second == null) {
                        Toast.makeText(context, "모든 항목을 입력하세요", Toast.LENGTH_SHORT).show()
                    } else {
                        // Firestore에 저장 로직 작성
                        Toast.makeText(context, "여행 생성 완료!", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("만들기")
            }
        }

//        if (showCountrySheet.value) {
//            CountryBottomSheet(
//                onDismiss = { showCountrySheet.value = false },
//                onCountrySelected = {
//                    selectedCountry.value = it
//                    showCountrySheet.value = false
//                }
//            )
//        }
//
//        if (showDateSheet.value) {
//            DateBottomSheet(
//                onDismiss = { showDateSheet.value = false },
//                onDateSelected = { start, end ->
//                    selectedDates.value = start to end
//                    showDateSheet.value = false
//                }
//            )
//        }
    }
}
