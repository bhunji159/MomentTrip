package com.example.momenttrip.ui.screen.main

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun AddTripScreen(modifier: Modifier = Modifier) {
    
}