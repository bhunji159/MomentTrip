package com.example.momenttrip.ui.screen.main

import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.momenttrip.viewmodel.UserViewModel

@Composable
fun MainScreen(
    onLogout: () -> Unit
) {
    val viewModel: UserViewModel = viewModel()
    val isTraveling = remember { mutableStateOf<Boolean?>(null) }

    LaunchedEffect(Unit) {
        viewModel.fetchCurrentTripStatus {
            isTraveling.value = it
        }
    }

    when (isTraveling.value) {
        null -> {
            LoadingScreen()
        }
        true -> {
            CurrentTripScreen()
        }
        false -> {
            AddTripScreen(onLogout = onLogout)
        }
    }
}

@Composable
fun LoadingScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}
