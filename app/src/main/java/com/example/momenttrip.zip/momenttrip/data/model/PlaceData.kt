package com.example.momenttrip.data.model

data class PlaceData(
    val name: String,
    val x: String, // 경도
    val y: String  // 위도
)
