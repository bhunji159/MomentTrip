package com.example.momenttrip.data

data class CountryData(
    val name: String,
    val currencyCode: String
)
