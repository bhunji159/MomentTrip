package com.example.momenttrip.data.model

data class PlaceSearchResponse(
    val places: List<PlaceData>
)
