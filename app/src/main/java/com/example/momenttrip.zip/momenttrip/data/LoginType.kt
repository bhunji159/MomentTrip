package com.example.momenttrip.data

enum class LoginType {
    EMAIL, GOOGLE, FACEBOOK
}